from Aufgabe1 import Complex

a = Complex(5, -2)
print(a)